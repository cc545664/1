<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * Localized language
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'live_zXoqO' );

/** Database username */
define( 'DB_USER', 'live_user_zXoqO' );

/** Database password */
define( 'DB_PASSWORD', '0k4YDIWwa9CZ2RwYnawVNCsrym2r6LlkEv' );

/** Database hostname */
define( 'DB_HOST', 'mysql.10web.site' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          ',*{@MjUHa]hOE%[.c?y.i<dAA1^623%_H~d0bRWr&S#`~<8S~<rl?!]uWBfSU9i&' );
define( 'SECURE_AUTH_KEY',   'Hwj7K {F:F08V4 x[@4WK9+URt35_sIacf?ArAOa1K^)z!vm}7k6/A>&8=O?;x{:' );
define( 'LOGGED_IN_KEY',     'X+YArtL=6=U;t?~I}I|k|!`;E2Dnm9 >W79;99N4u!n!0Y7T&@sZJY.h5Iw5(X)*' );
define( 'NONCE_KEY',         'Hj{mCF#%]`>Nb/Ylp43JJ 0rxC$h5xZsy%SPzYK*u_4G!&`VH]p=GLy^LI7I68%`' );
define( 'AUTH_SALT',         'bl^0gChy$qce:5:T]gsgL/%[&Sq#cnvQSasXB<PNn1%DAxE;K6Q>M&%tzOgh:ov2' );
define( 'SECURE_AUTH_SALT',  '3lT$UQ;2jlG!LoRKI+V1}&aXb-Ih_3o[:y:Ry`xFrSSBY&w8dK}v_>nklq#:]Y{u' );
define( 'LOGGED_IN_SALT',    'LuK?z2bGE=J94/(?y[JsY>6ZS|K^,%g$0J]Je4p.z8V]Yj~lYU|3OuZ/Uf4CLE(,' );
define( 'NONCE_SALT',        'ih88HmU ~cdN+.>(pPIBsS6)%JlqJ%W:W%EE<0>CMoqX_`jdbi&*7FJ_$$;bx%mi' );
define( 'WP_CACHE_KEY_SALT', '~F[]5a~N]P/Wg~qylCcgU&t{#`p@KRt`AO}gj-9/<z!_)H{Lj<]G,notPW%YRb>Y' );


/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );


/* Add any custom values between this line and the "stop editing" line. */



define( 'WP_MEMORY_LIMIT', '256M' );
define( 'TENWEB_CACHE', '1' );
/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
